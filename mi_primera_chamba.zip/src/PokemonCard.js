import React from 'react';
import { Link } from 'react-router-dom';

function PokemonCard({ pokemon }) {
  return (
    <Link to={`/pokemon/${pokemon.id}`} className="pokemon-card">
      <img
        src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.id}.png`}
        alt={pokemon.name}
      />
      <h3>{pokemon.name}</h3>
      <p>#{pokemon.id}</p>
    </Link>
  );
}

export default PokemonCard;
