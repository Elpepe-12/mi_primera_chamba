import React, { useState, useEffect } from 'react';
import PokemonCard from './PokemonCard';

function PokemonList() {
  const [pokemonList, setPokemonList] = useState([]);

  useEffect(() => {
    fetch('https://pokeapi.co/api/v2/pokemon?limit=151')
      .then(response => response.json())
      .then(async data => {
        const promises = data.results.map(p => fetch(p.url).then(res => res.json()));
        const results = await Promise.all(promises);
        setPokemonList(results);
      });
  }, []);

  return (
    <div className="pokemon-list">
      {pokemonList.map(pokemon => (
        <PokemonCard key={pokemon.id} pokemon={pokemon} />
      ))}
    </div>
  );
}

export default PokemonList;
